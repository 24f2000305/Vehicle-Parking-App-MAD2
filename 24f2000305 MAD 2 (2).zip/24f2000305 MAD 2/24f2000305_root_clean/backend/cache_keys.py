"""Centralized cache key constants."""

ADMIN_LOTS_CACHE_KEY = "admin:lots"
ADMIN_DASHBOARD_CACHE_KEY = "admin:dashboard"
USER_LOTS_CACHE_KEY = "user:lots"
