"""Celery background tasks for exports, reminders, and reports."""

from __future__ import annotations

import os
import smtplib
from collections import Counter
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Callable

from celery import Celery, Task

from .models import export_jobs, lots, reservations, users

EXPORT_DIR = Path("exports")
NOTIFICATION_DIR = Path("notifications")
REPORT_DIR = Path("reports")

_run_export_task: Task | None = None
_daily_task: Task | None = None
_monthly_task: Task | None = None


def _ensure_dir(path: Path) -> Path:
    # Ensure directory exists.
    path.mkdir(exist_ok=True)
    return path


def _register(celery_app: Celery, func: Callable[..., None], name: str) -> Task:
    return celery_app.task(name=name)(func)


def _log_email(subject: str, body: str) -> None:
    # Store pseudo-email content for demo purposes.
    log_file = _ensure_dir(NOTIFICATION_DIR) / "outbox.txt"
    stamp = datetime.now(timezone.utc).isoformat()
    lines = [f"[{stamp}] Subject: {subject}", body, "-" * 40]
    with log_file.open("a", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")


def _send_email(subject: str, body: str, *, html: str | None, recipients: list[str]) -> None:
    # MailHog configuration: localhost:1025 (no auth required)
    host = os.getenv("SMTP_HOST", "localhost")
    sender = os.getenv("SMTP_FROM", "parking-system@localhost")
    if not recipients:
        return
    port = int(os.getenv("SMTP_PORT", "1025"))  # MailHog default port
    username = os.getenv("SMTP_USERNAME")  # MailHog doesn't need auth
    password = os.getenv("SMTP_PASSWORD")

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = ", ".join(recipients)
    if html:
        message.set_content(body)
        message.add_alternative(html, subtype="html")
    else:
        message.set_content(body)

    try:
        with smtplib.SMTP(host, port) as server:
            # MailHog doesn't require STARTTLS or authentication
            # Only use auth if credentials are provided (for other SMTP servers)
            if username and password:
                server.starttls()
                server.login(username, password)
            server.send_message(message)
            print(f"✓ Email sent to {recipients}: {subject}")
    except Exception as e:
        print(f"✗ Failed to send email: {e}")


def _dispatch_email(subject: str, body: str, *, html: str | None = None, recipients: list[str] | None = None) -> None:
    _log_email(subject, body)
    fallback = [addr.strip() for addr in os.getenv("SMTP_TO", "").split(",") if addr.strip()]
    targets = recipients or fallback
    if not targets:
        return
    try:
        _send_email(subject, body, html=html, recipients=targets)
    except Exception as exc:  # pragma: no cover - demo logging for failures
        _log_email("Email send failed", f"{subject} -> {exc}")


def configure(celery_app: Celery) -> None:
    # Register Celery tasks.
    global _run_export_task, _daily_task, _monthly_task
    _run_export_task = _register(celery_app, run_export_job, "backend.tasks.run_export_job")
    _daily_task = _register(celery_app, send_daily_reminders, "backend.tasks.send_daily_reminders")
    _monthly_task = _register(celery_app, send_monthly_reports, "backend.tasks.send_monthly_reports")


def enqueue_export(job_id: int) -> None:
    # Queue export job for async processing.
    if _run_export_task is None:
        raise RuntimeError("Celery tasks not configured")
    _run_export_task.delay(job_id)


def run_export_job(job_id: int) -> None:
    # Generate CSV export for user reservations.
    job = export_jobs.get_job(job_id)
    if not job:
        return
    export_jobs.mark_processing(job_id)
    rows = reservations.list_user_reservations(int(job["user_id"]))
    export_dir = _ensure_dir(EXPORT_DIR)
    file_path = export_dir / f"export_{job['user_id']}_{job_id}.csv"
    lines = ["reservation_id,spot_id,lot,parked_at,left_at,cost"]
    for row in rows:
        lines.append(
            ",".join(
                [
                    str(row.get("id", "")),
                    str(row.get("spot_id", "")),
                    str(row.get("lot", "")),
                    str(row.get("parked_at", "")),
                    str(row.get("left_at", "")),
                    str(row.get("cost", "")),
                ]
            )
        )
    file_path.write_text("\n".join(lines), encoding="utf-8")
    export_jobs.mark_completed(job_id, str(file_path.resolve()))


def send_daily_reminders() -> None:
    # Send daily reminder logs for inactive users.
    cutoff = datetime.now(timezone.utc) - timedelta(days=1)
    since = cutoff.isoformat()
    available_lots = lots.list_available_lots()
    if not available_lots:
        print("⊘ No available parking lots - skipping daily reminders")
        return
    
    all_users = users.list_all_users()
    user_list = [u for u in all_users if u.get("role") == "user"]
    print(f" Checking {len(user_list)} user(s) for daily reminders...")
    
    reminders: list[str] = []
    for user in user_list:
        recent = reservations.recent_activity_count(int(user["id"]), since)
        if recent != 0:
            print(f"  ✓ {user['username']}: {recent} booking(s) in last 24h - no reminder needed")
            continue
        print(f"  ⚠ {user['username']}: No recent activity - sending reminder")
        message = (
            f"{datetime.now(timezone.utc).isoformat()} :: {user['username']} :: please book a spot if needed"
        )
        reminders.append(message)
        recipient = user.get("email")
        if recipient:
            _dispatch_email(
                subject="Parking Daily Reminder",
                body=(
                    "Hello {name},\n\nOur records show you haven't had any parking activity in the last day. "
                    "If you still need a spot, please log in and reserve one."
                ).format(name=user.get("username", "user")),
                recipients=[recipient],
            )
    if reminders:
        log_file = _ensure_dir(NOTIFICATION_DIR) / f"reminders_{datetime.now(timezone.utc).date()}.txt"
        with log_file.open("a", encoding="utf-8") as handle:
            handle.write("\n".join(reminders) + "\n")
        _dispatch_email(
            subject="Parking Daily Reminder Summary",
            body="\n".join(reminders),
        )
        print(f"✓ Sent {len(reminders)} daily reminder(s)")
    else:
        print("✓ No reminders needed - all users have recent activity")


def send_monthly_reports() -> None:
    # Generate monthly activity reports for all users.
    window_start = datetime.now(timezone.utc) - timedelta(days=30)
    since = window_start.isoformat()
    report_dir = _ensure_dir(REPORT_DIR)
    for user in users.list_all_users():
        if user.get("role") != "user":
            continue
        bookings = reservations.monthly_summary(int(user["id"]), since)
        if not bookings:
            continue
        total_cost = sum(float(entry.get("cost") or 0) for entry in bookings)
        lot_counter = Counter(entry.get("lot") for entry in bookings if entry.get("lot"))
        most_used = lot_counter.most_common(1)[0][0] if lot_counter else "N/A"
        rows = "".join(
            f"<tr><td>{entry.get('id')}</td><td>{entry.get('lot')}</td><td>{entry.get('parked_at')}</td><td>{entry.get('left_at') or ''}</td><td>{entry.get('cost')}</td></tr>"
            for entry in bookings
        )
        html = f"""
        <html>
          <body>
            <h2>Monthly Activity Report for {user.get('username')}</h2>
            <p>Total Reservations: {len(bookings)}</p>
            <p>Total Cost: {total_cost:.2f}</p>
            <p>Most Used Lot: {most_used}</p>
            <table border="1" cellpadding="4">
              <thead><tr><th>ID</th><th>Lot</th><th>Parked At</th><th>Left At</th><th>Cost</th></tr></thead>
              <tbody>{rows}</tbody>
            </table>
          </body>
        </html>
        """
        report_file = report_dir / f"report_{user.get('username')}_{datetime.now(timezone.utc).date()}.html"
        report_file.write_text(html, encoding="utf-8")
        recipient = user.get("email")
        _dispatch_email(
            subject=f"Monthly Parking Report – {user.get('username')}",
            body=(
                "Hello {name},\n\nYour monthly parking activity report is ready. "
                "You can download the HTML summary from {path}."
            ).format(name=user.get("username", "user"), path=report_file.resolve()),
            html=html,
            recipients=[recipient] if recipient else None,
        )


__all__ = ["configure", "enqueue_export"]
