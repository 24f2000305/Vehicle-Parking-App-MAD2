"""Backend package initialization."""

from .app import app, celery  # noqa: F401
