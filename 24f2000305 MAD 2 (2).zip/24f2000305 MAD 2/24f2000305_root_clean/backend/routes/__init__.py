"""Routes package for all API blueprints."""

from . import admin, auth, user  # noqa: F401
