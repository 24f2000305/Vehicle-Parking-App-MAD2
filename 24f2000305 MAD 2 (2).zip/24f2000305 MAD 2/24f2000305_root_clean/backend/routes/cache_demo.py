"""API endpoints for cache demonstration and monitoring."""

from __future__ import annotations

from datetime import datetime

from flask import Blueprint, jsonify
from flask_login import login_required

from ..cache_keys import ADMIN_DASHBOARD_CACHE_KEY, ADMIN_LOTS_CACHE_KEY, USER_LOTS_CACHE_KEY
from ..extensions import cache
from ..models import lots

bp = Blueprint("cache_demo", __name__, url_prefix="/api/cache")


@bp.get("/info")
def cache_info():
    """Get cache configuration and status."""
    return jsonify({
        "cache_type": "RedisCache",
        "redis_host": "localhost",
        "redis_port": 6379,
        "default_timeout": 300,
        "cache_keys": {
            "user_lots": USER_LOTS_CACHE_KEY,
            "admin_lots": ADMIN_LOTS_CACHE_KEY,
            "admin_dashboard": ADMIN_DASHBOARD_CACHE_KEY,
        }
    })


@bp.get("/status")
@login_required
def cache_status():
    """Check which cache keys are currently set."""
    keys = [USER_LOTS_CACHE_KEY, ADMIN_LOTS_CACHE_KEY, ADMIN_DASHBOARD_CACHE_KEY]
    status = {}
    
    for key in keys:
        cached_data = cache.get(key)
        status[key] = {
            "cached": cached_data is not None,
            "data_preview": str(cached_data)[:100] if cached_data else None,
        }
    
    return jsonify(status)


@bp.get("/test")
def cache_test():
    """Demonstrate cache with expiry."""
    cache_key = "test:cache-demo"
    
    # Check if data is cached
    cached = cache.get(cache_key)
    
    if cached:
        return jsonify({
            "source": "cache",
            "cached_at": cached["timestamp"],
            "message": "This data was retrieved from Redis cache!",
            "data": cached["data"],
            "ttl_seconds": 60,
        })
    
    # Generate fresh data
    fresh_data = {
        "timestamp": datetime.utcnow().isoformat(),
        "data": {
            "total_lots": len(lots.list_all_lots()),
            "random_number": hash(datetime.utcnow()) % 1000,
        }
    }
    
    # Cache for 60 seconds
    cache.set(cache_key, fresh_data, timeout=60)
    
    return jsonify({
        "source": "database",
        "cached_at": fresh_data["timestamp"],
        "message": "Fresh data generated and cached for 60 seconds",
        "data": fresh_data["data"],
        "ttl_seconds": 60,
    })


@bp.post("/clear")
@login_required
def clear_cache():
    """Clear all application caches."""
    keys = [USER_LOTS_CACHE_KEY, ADMIN_LOTS_CACHE_KEY, ADMIN_DASHBOARD_CACHE_KEY, "test:cache-demo"]
    cleared = []
    
    for key in keys:
        if cache.get(key) is not None:
            cache.delete(key)
            cleared.append(key)
    
    return jsonify({
        "message": f"Cleared {len(cleared)} cache keys",
        "cleared_keys": cleared,
    })


@bp.get("/ttl-demo")
def ttl_demo():
    """Demonstrate different TTL values."""
    demos = []
    
    # 30 second cache
    key_30s = "demo:30s"
    if cache.get(key_30s) is None:
        cache.set(key_30s, {"created": datetime.utcnow().isoformat()}, timeout=30)
        demos.append({"key": key_30s, "ttl": 30, "status": "created"})
    else:
        demos.append({"key": key_30s, "ttl": 30, "status": "cached"})
    
    # 60 second cache
    key_60s = "demo:60s"
    if cache.get(key_60s) is None:
        cache.set(key_60s, {"created": datetime.utcnow().isoformat()}, timeout=60)
        demos.append({"key": key_60s, "ttl": 60, "status": "created"})
    else:
        demos.append({"key": key_60s, "ttl": 60, "status": "cached"})
    
    # 120 second cache
    key_120s = "demo:120s"
    if cache.get(key_120s) is None:
        cache.set(key_120s, {"created": datetime.utcnow().isoformat()}, timeout=120)
        demos.append({"key": key_120s, "ttl": 120, "status": "created"})
    else:
        demos.append({"key": key_120s, "ttl": 120, "status": "cached"})
    
    return jsonify({
        "message": "Cache TTL demonstration",
        "demos": demos,
        "note": "Refresh this endpoint to see which caches expire first"
    })


__all__ = ["bp"]
