# Vehicle Parking Management System

**Modern Application Development II (MAD2) Project**

A comprehensive full-stack parking management system with Flask REST API, Vue.js 3 frontend, Redis caching, and Celery background processing.

---

## Table of Contents

1.  [Project Overview](#project-overview)
2.  [Features](#features)
3.  [Technology Stack](#technology-stack)
4.  [Installation](#installation)
5.  [Running the Application](#running-the-application)
6.  [Project Structure](#project-structure)
7.  [API Documentation](#api-documentation)
8.  [Database Schema](#database-schema)
9.  [Background Jobs](#background-jobs)
10.  [Caching Strategy](#caching-strategy)
11.  [Default Credentials](#default-credentials)

---

## Project Overview

The Vehicle Parking Management System is a web-based application designed to streamline parking lot operations. It provides separate interfaces for administrators to manage parking facilities and users to book and manage their parking reservations.

### Key Highlights

-   **Programmatic Database Creation**: No manual database setup required
-   **Auto-Generated Parking Spots**: Admin specifies capacity; system creates individual spots
-   **Multiple Vehicle Bookings**: Users can book multiple spots for the same vehicle
-   **Async Background Jobs**: Daily reminders, monthly reports, CSV exports
-   **Redis Caching**: 10x performance improvement for frequently accessed data
-   **RESTful API**: Clean separation between frontend and backend

---

## Features

### Administrator Features

-   Create and manage parking lots with dynamic capacity
-   Auto-generate parking spots based on total capacity
-   View real-time dashboard with occupancy statistics
-   Monitor all user reservations across the system
-   Manage user accounts and access
-   Cache invalidation for real-time data consistency

### User Features

-   Self-registration and profile management
-   Browse available parking lots with live availability
-   Book single or multiple parking spots
-   Vehicle number validation (format: XXNNXXNNNN)
-   View active and historical reservations
-   Release parking spots with automatic cost calculation
-   Export reservation history as CSV (async processing)

### Background Jobs

1.  **Daily Reminders**: Automated emails to inactive users (6:00 PM daily)
2.  **Monthly Reports**: HTML activity reports with usage statistics (1st of month)
3.  **CSV Export**: User-triggered asynchronous data export

---

## Technology Stack

### Backend

-   **Flask 2.3**: Python web framework
-   **Flask-Login**: Session management and authentication
-   **Flask-Caching**: Redis-based caching layer
-   **SQLite**: Lightweight relational database
-   **Celery 5**: Distributed task queue
-   **Redis**: Message broker and cache backend

### Frontend

-   **Vue.js 3** (CDN): Progressive JavaScript framework
-   **Bootstrap 5**: Responsive CSS framework
-   **ES Modules**: Component-based architecture without build tools

### Development Tools

-   Python 3.8+
-   Redis Server
-   Virtual Environment (venv)

---

## Installation

### Prerequisites

```bash
# Required software:- Python 3.8 or higher- Redis Server- Git (optional)
```

### Setup Steps

1.  **Extract/Clone the project**
    
2.  **Create virtual environment**:
    
    ```powershell
    python -m venv venv
    ```
    
3.  **Activate virtual environment**:
    
    ```powershell
    # WindowsvenvScriptsactivate# Linux/Macsource venv/bin/activate
    ```
    
4.  **Install dependencies**:
    
    ```powershell
    pip install -r requirements.txt
    ```
    
5.  **Database initialization**:
    
    -   Automatic on first run
    -   Default admin account created automatically
    -   No manual setup required

---

## Running the Application

The system requires four services running simultaneously in separate terminals:

### Terminal 1: Redis Server

```powershell
redis-server
```

### Terminal 2: Flask Application

```powershell
python app.py
```

**Access the application at**: [http://localhost:5000](http://localhost:5000)

### Terminal 3: Celery Worker (Background Jobs)

```powershell
celery -A app.celery worker --loglevel=info --pool=solo
```

### Terminal 4: Celery Beat (Scheduled Tasks)

```powershell
celery -A app.celery beat --loglevel=info
```

---

## Project Structure

```
Vehicle parking system/│├── app.py                      # Application entry point├── requirements.txt            # Python dependencies├── README.md                   # Project documentation├── .gitignore                  # Git ignore rules│├── backend/                    # Backend application│   ├── app.py                  # Flask app factory & Celery config│   ├── extensions.py           # Flask extensions (cache, login)│   ├── cache_keys.py           # Cache key constants│   ├── tasks.py                # Celery background tasks│   ││   ├── models/                 # Database models│   │   ├── db.py               # Database connection & schema│   │   ├── users.py            # User operations│   │   ├── lots.py             # Parking lot operations│   │   ├── reservations.py    # Reservation operations│   │   └── export_jobs.py      # Export job tracking│   ││   └── routes/                 # API endpoints│       ├── auth.py             # Authentication routes│       ├── admin.py            # Admin routes│       ├── user.py             # User routes│       └── cache_demo.py       # Caching demo routes│├── frontend/                   # Frontend application│   ├── index.html              # Main HTML file│   └── src/│       ├── main.js             # Vue app initialization│       ├── api.js              # API client│       ││       └── components/         # Vue components│           ├── AuthPane.js     # Authentication component│           ├── AdminPanel.js   # Admin dashboard│           ├── UserPanel.js    # User dashboard│           ││           ├── admin/          # Admin-specific components│           │   ├── AdminDashboard.js│           │   ├── AdminLots.js│           │   ├── AdminUsers.js│           │   └── AdminReservations.js│           ││           └── user/           # User-specific components│               ├── UserBooking.js│               ├── UserActiveReservations.js│               ├── UserHistory.js│               ├── UserExports.js│               └── UserStats.js│├── exports/                    # Generated CSV files (runtime)├── reports/                    # Monthly HTML reports (runtime)└── notifications/              # Email logs (runtime)
```

---

## API Documentation

### Authentication Endpoints

Method

Endpoint

Description

POST

`/api/auth/register`

Register new user

POST

`/api/auth/login`

User login

GET

`/api/auth/profile`

Get current user

POST

`/api/auth/logout`

User logout

### User Endpoints

Method

Endpoint

Description

GET

`/api/user/lots`

List available parking lots

POST

`/api/user/reservations`

Create reservation

GET

`/api/user/reservations`

List user reservations

POST

`/api/user/reservations/{id}/release`

Release parking spot

POST

`/api/user/exports`

Request CSV export

GET

`/api/user/exports`

List export jobs

GET

`/api/user/exports/{id}/download`

Download CSV file

### Admin Endpoints

Method

Endpoint

Description

GET

`/api/admin/lots`

List all parking lots

POST

`/api/admin/lots`

Create parking lot

PATCH

`/api/admin/lots/{id}`

Update parking lot

DELETE

`/api/admin/lots/{id}`

Delete parking lot

GET

`/api/admin/dashboard`

Dashboard statistics

GET

`/api/admin/users`

List all users

GET

`/api/admin/reservations`

List all reservations

---

## Database Schema

### Users Table

```sql
CREATE TABLE users (    id INTEGER PRIMARY KEY AUTOINCREMENT,    username TEXT UNIQUE NOT NULL,    email TEXT UNIQUE,    password_hash TEXT NOT NULL,    role TEXT NOT NULL DEFAULT 'user',    created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
```

### Parking Lots Table

```sql
CREATE TABLE parking_lots (    id INTEGER PRIMARY KEY AUTOINCREMENT,    name TEXT NOT NULL,    price_per_hour REAL NOT NULL,    address TEXT,    pin_code TEXT,    total_spots INTEGER NOT NULL,    created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
```

### Parking Spots Table

```sql
CREATE TABLE parking_spots (    id INTEGER PRIMARY KEY AUTOINCREMENT,    lot_id INTEGER NOT NULL,    status TEXT NOT NULL DEFAULT 'A',    FOREIGN KEY (lot_id) REFERENCES parking_lots(id) ON DELETE CASCADE);
```

-   Status: 'A' = Available, 'O' = Occupied

### Reservations Table

```sql
CREATE TABLE reservations (    id INTEGER PRIMARY KEY AUTOINCREMENT,    spot_id INTEGER NOT NULL,    user_id INTEGER NOT NULL,    vehicle_number TEXT NOT NULL,    parked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,    left_at DATETIME,    cost REAL DEFAULT 0,    FOREIGN KEY (spot_id) REFERENCES parking_spots(id),    FOREIGN KEY (user_id) REFERENCES users(id));
```

### Export Jobs Table

```sql
CREATE TABLE export_jobs (    id INTEGER PRIMARY KEY AUTOINCREMENT,    user_id INTEGER NOT NULL,    status TEXT NOT NULL DEFAULT 'pending',    file_path TEXT,    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,    completed_at DATETIME,    FOREIGN KEY (user_id) REFERENCES users(id));
```

---

## Background Jobs

### 1. Daily Reminders (Scheduled)

**Schedule**: 6:00 PM daily

**Function**: Send reminder emails to inactive users

**Implementation**: `backend/tasks.py` - `send_daily_reminders()`

**Logic**:

-   Checks users with no parking activity in last 24 hours
-   Sends email reminders to book parking if needed
-   Creates log files in `notifications/` directory
-   Provides detailed console output showing which users need reminders

**Console Output Example**:

```
📋 Checking 2 user(s) for daily reminders...  ✓ sachinmaurya: 3 booking(s) in last 24h - no reminder needed  ⚠ testuser: No recent activity - sending reminder✓ Email sent to ['testuser@example.com']: Parking Daily Reminder✓ Sent 1 daily reminder(s)
```

**Configuration**: `backend/app.py`

```python
"daily-reminder": {    "task": "backend.tasks.send_daily_reminders",    "schedule": crontab(hour=18, minute=0),}
```

### 2. Monthly Reports (Scheduled)

**Schedule**: 1st of each month at 6:10 PM

**Function**: Generate comprehensive activity reports

**Implementation**: `backend/tasks.py` - `send_monthly_reports()`

**Report Includes**:

-   Total reservations for the month
-   Total cost spent on parking
-   Most frequently used parking lot
-   Detailed table of all bookings

**Output**: HTML file saved in `reports/` and sent via email

### 3. CSV Export (User-Triggered)

**Trigger**: User-initiated from dashboard

**Function**: Generate CSV file with reservation history

**Implementation**: `backend/tasks.py` - `run_export_job()`

**CSV Format**:

```csv
reservation_id,spot_id,lot,parked_at,left_at,cost1,5,Downtown Parking,2025-11-29T10:30:00,2025-11-29T12:30:00,11.0
```

**Process Flow**:

1.  User clicks export button
2.  Job queued in database (status: pending)
3.  Celery worker processes in background
4.  Status updated to completed
5.  Download link provided to user

---

## Caching Strategy

### Configuration

**Redis-based caching** with automatic expiry:

```python
CACHE_TYPE = "RedisCache"CACHE_REDIS_HOST = "localhost"CACHE_REDIS_PORT = 6379CACHE_DEFAULT_TIMEOUT = 300
```

### Cached Endpoints

Endpoint

TTL

Description

`/api/user/lots`

120s

Available parking lots

`/api/admin/lots`

300s

All parking lots with stats

`/api/admin/dashboard`

300s

System statistics

### Cache Invalidation

**Automatic cache clearing** occurs on:

-   Parking lot creation/update/deletion
-   Reservation creation/release
-   Admin data modifications

**Manual cache clearing**: `POST /api/cache/clear`

### Performance Impact

-   **Without cache**: 50-100ms per request
-   **With cache**: 5-10ms per request
-   **Performance gain**: ~10x faster

---

## Default Credentials

### Administrator Account

```
Username: adminPassword: admin123
```

### User Accounts

Register new accounts through the application UI at [http://localhost:5000](http://localhost:5000)

---

## Key Implementation Features

### 1. Programmatic Database Creation

-   Database schema defined in Python code (`backend/models/db.py`)
-   Automatic initialization on first application run
-   No manual database tools (DB Browser) required
-   Default admin account auto-created

### 2. Auto-Generated Parking Spots

-   Admin specifies `total_spots` when creating parking lot
-   System automatically creates individual parking spots
-   Implementation: `backend/models/lots.py` - `create_lot()` function
-   No need to add spots one by one

### 3. Multiple Vehicle Number Bookings

-   Users can book multiple spots in single transaction
-   Quantity parameter: 1-10 spots per booking
-   Vehicle number format validation: XXNNXXNNNN
-   Example: AB12CD3456
-   Implementation: `backend/routes/user.py`

### 4. Asynchronous Processing

-   Non-blocking CSV export generation
-   Background email sending for reminders
-   Improved user experience (immediate response)
-   Scalable architecture using Celery

### 5. Vue.js CDN Architecture

-   No build tools required (webpack, vite, etc.)
-   Browser-native ES modules
-   Components use JavaScript template strings
-   Fast development with instant browser refresh

---

## Development Decisions

### Why Vue.js CDN?

-   Meets project requirements (no build tools)
-   Simple deployment (no compilation step)
-   All Vue 3 features available
-   Educational focus on concepts, not tooling

### Why SQLite?

-   Lightweight and portable
-   No separate database server required
-   Perfect for learning and development
-   Easy to demonstrate programmatic database creation

### Why Celery?

-   Industry-standard for Python background jobs
-   Supports scheduled tasks (Celery Beat)
-   Scalable for production use
-   Clear separation of concerns

---

## Testing the Application

### Manual Testing Steps

1.  **Admin Workflow**:
    
    -   Login with admin credentials
    -   Create parking lot (e.g., 50 spots @ ₹5/hour)
    -   View dashboard statistics
    -   Monitor user reservations
2.  **User Workflow**:
    
    -   Register new account
    -   Browse available parking lots
    -   Book parking spot with vehicle number
    -   View active reservations
    -   Release spot and verify cost calculation
    -   Export reservation history
3.  **Background Jobs**:
    
    -   Wait for daily reminder (6:00 PM) or run manually
    -   Check `notifications/` folder for logs
    -   Wait for monthly report (1st of month) or run manually
    -   Check `reports/` folder for HTML files
4.  **Caching**:
    
    -   Access `/api/cache/test` twice and compare response times
    -   View cache status at `/api/cache/status`
    -   Clear cache with `/api/cache/clear`

---

## Troubleshooting

### Common Issues

**Issue**: Cannot connect to Redis

```powershell
# Solution: Ensure Redis is runningredis-server
```

**Issue**: Celery worker not processing jobs

```powershell
# Solution: Check if worker is runningcelery -A app.celery worker --loglevel=info --pool=solo
```

**Issue**: Scheduled jobs not executing

```powershell
# Solution: Ensure Celery Beat is runningcelery -A app.celery beat --loglevel=info
```

**Issue**: Database locked error

```powershell
# Solution: Close all connections and restart Flask# Stop Flask (Ctrl+C) and start againpython app.py
```

---

## Project Submission Checklist

-    Database created programmatically
-    Admin creates lots with auto-generated spots
-    Users book multiple spots with vehicle numbers
-    Daily reminders (scheduled job)
-    Monthly reports (scheduled job)
-    CSV export (async job)
-    Redis caching with expiry
-    Clean code structure
-    README documentation
-    .gitignore configuration
-    Requirements.txt updated

---

## Future Enhancements

-   Payment gateway integration
-   Real-time notifications using WebSockets
-   Mobile application (React Native/Flutter)
-   Advanced analytics with Chart.js
-   QR code generation for parking spots
-   Email service integration (SendGrid/AWS SES)

---

## References

-   [Flask Documentation](https://flask.palletsprojects.com/)
-   [Vue.js 3 Guide](https://vuejs.org/)
-   [Celery Documentation](https://docs.celeryq.dev/)
-   [Redis Documentation](https://redis.io/documentation)
-   [Flask-Login Documentation](https://flask-login.readthedocs.io/)

---

**Developed for MAD2 (Modern Application Development II) Course**

**Academic Year**: 2024-2025

---

# Demo Commands for Evaluation

## Backend Jobs Demonstration

### 1. Daily Reminder

```powershell
python -c "from backend.tasks import send_daily_reminders; send_daily_reminders(); print('Check MailHog at http://localhost:8025')"
```

### 2. Monthly Report

```powershell
python -c "from backend.tasks import send_monthly_reports; send_monthly_reports(); print('Check MailHog at http://localhost:8025 and reports/ folder')"
```

### 3. API Testing with Thunder Client

**Key Endpoints to Test:**

1.  **Login** (POST)
    
    -   URL: `http://localhost:5000/api/auth/login`
    -   Body (JSON):
        
        ```json
        {  "username": "admin",  "password": "admin123"}
        ```
        
2.  **Get Dashboard Stats** (GET)
    
    -   URL: `http://localhost:5000/api/admin/dashboard`
    -   Shows caching in action (check response time on 2nd call)
3.  **List Parking Lots** (GET)
    
    -   URL: `http://localhost:5000/api/user/lots`
    -   Cached endpoint (TTL: 120s)
4.  **Create Parking Lot** (POST - Admin only)
    
    -   URL: `http://localhost:5000/api/admin/lots`
    -   Body (JSON):
        
        ```json
        {  "name": "Test Lot",  "price_per_hour": 10,  "address": "123 Main St",  "pin_code": "110001",  "total_spots": 20}
        ```
        
    -   Shows auto-generation of parking spots
5.  **Request CSV Export** (POST - User)
    
    -   URL: `http://localhost:5000/api/user/exports`
    -   Shows async job processing

**Quick Test Sequence:**

1.  Login as admin → Copy the response (session cookie auto-saved)
2.  Call dashboard twice → Note faster 2nd response (cache hit)
3.  Create a parking lot → Auto-generates 20 spots
4.  Check lots endpoint → Verify new lot appears

### 4. Caching Demonstration

**Test cache hit (call endpoint twice, second should be faster):**

```powershell
Write-Host "First call (cache miss):"; (Measure-Command { Invoke-RestMethod 'http://localhost:5000/api/cache/test' }).TotalMilliseconds; Write-Host "`nSecond call (cache hit):"; (Measure-Command { Invoke-RestMethod 'http://localhost:5000/api/cache/test' }).TotalMilliseconds
```

**View cache status:**

```powershell
Invoke-RestMethod 'http://localhost:5000/api/cache/status' | ConvertTo-Json
```

**Clear cache and test again (should be slow):**

```powershell
Invoke-RestMethod -Method Post -Uri 'http://localhost:5000/api/cache/clear'; Write-Host "`nCache cleared. Testing again:"; (Measure-Command { Invoke-RestMethod 'http://localhost:5000/api/cache/test' }).TotalMilliseconds
```

**Test cache TTL expiry:**

```powershell
Invoke-RestMethod 'http://localhost:5000/api/cache/ttl-demo' | ConvertTo-Json
```

---

## Quick Demo Script (Backend Jobs + Caching)

Run this single command to demonstrate daily reminders, monthly reports, and caching:

```powershell
Write-Host "=== 1. DAILY REMINDER ===" -ForegroundColor Green; python -c "from backend.tasks import send_daily_reminders; send_daily_reminders()"; Write-Host "`n=== 2. MONTHLY REPORT ===" -ForegroundColor Green; python -c "from backend.tasks import send_monthly_reports; send_monthly_reports()"; Write-Host "`n=== 3. CACHE DEMONSTRATION ===" -ForegroundColor Green; Write-Host "First call (miss):"; $time1 = (Measure-Command { Invoke-RestMethod 'http://localhost:5000/api/cache/test' }).TotalMilliseconds; Write-Host "$time1 ms"; Write-Host "Second call (hit):"; $time2 = (Measure-Command { Invoke-RestMethod 'http://localhost:5000/api/cache/test' }).TotalMilliseconds; Write-Host "$time2 ms"; Write-Host "`nSpeedup: $([math]::Round($time1/$time2, 2))x faster"; Write-Host "`n=== DONE - Check MailHog at http://localhost:8025 ===" -ForegroundColor Green
```

## Thunder Client Collection (Import-Ready)

Copy this JSON and import into Thunder Client (Thunder Client → Menu → Import):

```json
{  "clientName": "Thunder Client",  "collectionName": "Vehicle Parking API",  "requests": [    {      "name": "1. Login (Admin)",      "method": "POST",      "url": "http://localhost:5000/api/auth/login",      "body": {        "type": "json",        "raw": "{"username":"admin","password":"admin123"}"      }    },    {      "name": "2. Dashboard Stats (Cached)",      "method": "GET",      "url": "http://localhost:5000/api/admin/dashboard"    },    {      "name": "3. List Lots (Cached)",      "method": "GET",      "url": "http://localhost:5000/api/user/lots"    },    {      "name": "4. Create Lot (Auto-generates spots)",      "method": "POST",      "url": "http://localhost:5000/api/admin/lots",      "body": {        "type": "json",        "raw": "{"name":"Demo Lot","price_per_hour":15,"address":"456 Park Ave","pin_code":"110002","total_spots":25}"      }    },    {      "name": "5. Request CSV Export (Async Job)",      "method": "POST",      "url": "http://localhost:5000/api/user/exports"    }  ]}
```

---

## View Results

**MailHog Web UI (Emails):**

```
http://localhost:8025
```

**Generated Reports:**

```powershell
Get-ChildItem reports/*.html | Select-Object Name, LastWriteTime
```

**Open Latest Report:**

```powershell
$latest = Get-ChildItem reports/*.html | Sort-Object LastWriteTime -Descending | Select-Object -First 1; Start-Process $latest.FullName
```